package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.youssouf.thomassankara.R;

public class culturel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_culturel);
    }
}
