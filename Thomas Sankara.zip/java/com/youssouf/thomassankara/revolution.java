package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class revolution extends AppCompatActivity implements View.OnClickListener{
    Button culturel,impact,genre,logement,sante,securitaire,lutte,desert,monde;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_revolution);

        culturel= findViewById(R.id.culturel);
        impact = findViewById(R.id.impact);
        genre= findViewById(R.id.genre);
        logement= findViewById(R.id.logement);
        sante= findViewById(R.id.sante);
        securitaire = findViewById(R.id.securitaire);
        lutte= findViewById(R.id.lutte);
        desert= findViewById(R.id.desert);
        monde= findViewById(R.id.monde);

        culturel.setOnClickListener(this);
        impact.setOnClickListener(this);
        genre.setOnClickListener(this);
        logement.setOnClickListener(this);
        sante.setOnClickListener(this);
        securitaire.setOnClickListener(this);
        lutte.setOnClickListener(this);
        desert.setOnClickListener(this);
        monde.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.culturel:
                Intent intt = new Intent(this,culturel.class);
                startActivity(intt);
                break;
            case R.id.impact:
                Intent innt = new Intent(this,impact.class);
                startActivity(innt);
                break;
            case R.id.genre:
                Intent intnt = new Intent(this,genre.class);
                startActivity(intnt);
                break;
            case R.id.logement:
                Intent intent = new Intent(this,logement.class);
                startActivity(intent);
                break;
            case R.id.sante:
                Intent in = new Intent(this,sante.class);
                startActivity(in);
                break;
            case R.id.securitaire:
                Intent inn = new Intent(this,securitaire.class);
                startActivity(inn);
                break;
            case R.id.lutte:
                Intent intn = new Intent(this,lutte.class);
                startActivity(intn);
                break;
            case R.id.monde:
                Intent inte = new Intent(this,monde.class);
                startActivity(inte);
                break;
            case R.id.desert:
                Intent inten = new Intent(this,contre.class);
                startActivity(inten);
                break;
        }
    }
}
