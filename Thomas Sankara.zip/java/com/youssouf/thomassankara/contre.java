package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

public class contre extends AppCompatActivity {
    FragmentPagerAdapter adapterViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contre);

        ViewPager vpPager = findViewById(R.id.contre);
        adapterViewPager = new MyPagerAdapter(getSupportFragmentManager());
        vpPager.setAdapter(adapterViewPager);


    }
    public class MyPagerAdapter extends FragmentPagerAdapter {
        private  int NUM_ITEMS = 3;

        public MyPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }
        @Override
        public int getCount() {
            return NUM_ITEMS;
        }

        // Returns the fragment to display for that page
        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;
            switch (position) {
                case 0:
                    fragment = new Trois();
                    break;
                case 1:
                    fragment = new Reforest();
                    break;
                case 2:
                    fragment=new Barrages();
                    break;
            }
            return fragment;
        }
        @Override
        public CharSequence getPageTitle(int position) {
            String title= null;
            if (position==0)
                title = "Les Trois Luttes";
            else if (position==1)
                title = "Politique de Reboisement";
            else if (position == 2)
                title="Construction de Barrages";
            return title;
        }

    }
}
