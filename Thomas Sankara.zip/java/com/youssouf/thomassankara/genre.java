package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class genre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genre);
    }
}
