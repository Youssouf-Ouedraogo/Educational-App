package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class biographie extends AppCompatActivity implements View.OnClickListener{
    Button enfance,militaire,secretaire,misnistre,revolution,mort,vie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biographie);


        enfance=findViewById(R.id.enfance);
        militaire = findViewById(R.id.militaire);
        secretaire= findViewById(R.id.secretaire);
        misnistre= findViewById(R.id.ministre);
        revolution= findViewById(R.id.revolution);
        vie= findViewById(R.id.vie);
        mort= findViewById(R.id.mort);

        enfance.setOnClickListener(this);
        militaire.setOnClickListener(this);
        secretaire.setOnClickListener(this);
        misnistre.setOnClickListener(this);
        revolution.setOnClickListener(this);
        vie.setOnClickListener(this);
        mort.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.enfance:
                Intent myInten = new Intent(this,enfance.class);
                startActivity(myInten);
                break;
            case R.id.militaire:
                Intent myIntent = new Intent(this, miliraire.class);
                startActivity(myIntent);
                break;
            case R.id.secretaire:
                Intent myInent = new Intent(this,secretaire.class);
                startActivity(myInent);
                break;
            case R.id.ministre:
                Intent myIent = new Intent(this, misnistre.class);
                startActivity(myIent);
                break;
            case R.id.revolution:
                Intent myItent = new Intent(this, revolution.class);
                startActivity(myItent);
                break;
            case R.id.vie:
                Intent mIntent = new Intent(this, vie.class);
                startActivity(mIntent);
                break;
            case R.id.mort:
                Intent Intent = new Intent(this, mort.class);
                startActivity(Intent);
                break;
        }
    }
}
