package com.youssouf.thomassankara;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class francais extends Fragment implements View.OnClickListener {
    Button biographie, citation,realisation,reconnaissance;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_francais, container, false);

        biographie=view.findViewById(R.id.biographie);
        citation = view.findViewById(R.id.citation);
        realisation= view.findViewById(R.id.realisation);
        reconnaissance= view.findViewById(R.id.reconnaissance);

        biographie.setOnClickListener(this);
        citation.setOnClickListener(this);
        realisation.setOnClickListener(this);
        reconnaissance.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.realisation:
                Intent intt = new Intent(getActivity(),realisation.class);
                startActivity(intt);
                break;
            case R.id.reconnaissance:
                Intent innt = new Intent(getActivity(),reconnaissance.class);
                startActivity(innt);
                break;
            case R.id.biographie:
                Intent intnt = new Intent(getActivity(),biographie.class);
                startActivity(intnt);
                break;
            case R.id.citation:
                Intent intent = new Intent(getActivity(),citation.class);
                startActivity(intent);
                break;
        }

    }
}
