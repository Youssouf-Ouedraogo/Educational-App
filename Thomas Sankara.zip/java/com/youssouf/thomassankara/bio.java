package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class bio extends AppCompatActivity implements View.OnClickListener{
    Button bio, mili, secre,misnister, year, couple,death;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bio);

        bio=findViewById(R.id.child);
        mili = findViewById(R.id.military);
        secre= findViewById(R.id.secretary);
        misnister= findViewById(R.id.minister);
        year= findViewById(R.id.year);
        couple= findViewById(R.id.couple);
        death= findViewById(R.id.death);

        bio.setOnClickListener(this);
        mili.setOnClickListener(this);
        secre.setOnClickListener(this);
        misnister.setOnClickListener(this);
        year.setOnClickListener(this);
        couple.setOnClickListener(this);
        death.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.child:
                Intent myInten = new Intent(bio.this,early.class);
                startActivity(myInten);
                break;
            case R.id.military:
                Intent myIntent = new Intent(bio.this, military.class);
                startActivity(myIntent);
                break;
            case R.id.secretary:
                Intent myInent = new Intent(bio.this,secretary.class);
                startActivity(myInent);
                break;
            case R.id.minister:
                Intent myIent = new Intent(bio.this, minister.class);
                startActivity(myIent);
                break;
            case R.id.year:
                Intent myItent = new Intent(bio.this, president.class);
                startActivity(myItent);
                break;
            case R.id.couple:
                Intent mIntent = new Intent(bio.this, couple.class);
                startActivity(mIntent);
                break;
            case R.id.death:
                Intent Intent = new Intent(bio.this, death.class);
                startActivity(Intent);
                break;
        }
    }
}
