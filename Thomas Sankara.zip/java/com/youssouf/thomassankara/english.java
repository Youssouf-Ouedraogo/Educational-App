package com.youssouf.thomassankara;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class english extends Fragment implements View.OnClickListener{
    Button bio, accomplish, ack, quote;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_english, container, false);
        bio=view.findViewById(R.id.bio);
        quote = view.findViewById(R.id.quote);
        accomplish= view.findViewById(R.id.accomplish);
        ack= view.findViewById(R.id.ack);

        bio.setOnClickListener(this);
        quote.setOnClickListener(this);
        accomplish.setOnClickListener(this);
        ack.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.accomplish:
                Intent intt = new Intent(getActivity(),accomplish.class);
                startActivity(intt);
                break;
            case R.id.ack:
                Intent innt = new Intent(getActivity(),acknowledgement.class);
                startActivity(innt);
                break;
            case R.id.bio:
                Intent intnt = new Intent(getActivity(),bio.class);
                startActivity(intnt);
                break;
            case R.id.quote:
                Intent intent = new Intent(getActivity(),quotations.class);
                startActivity(intent);
                break;
        }
    }
}
