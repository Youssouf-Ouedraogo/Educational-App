package com.youssouf.thomassankara;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class president extends AppCompatActivity implements View.OnClickListener {
    Button culture, education, gender, transportation, health, security,corruption,desertification,world;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_president);
        culture= findViewById(R.id.culture);
        education = findViewById(R.id.education);
        gender= findViewById(R.id.gender);
        transportation= findViewById(R.id.transportation);
        health= findViewById(R.id.health);
        security = findViewById(R.id.security);
        corruption= findViewById(R.id.corruption);
        desertification= findViewById(R.id.desertification);
        world= findViewById(R.id.world);

        culture.setOnClickListener(this);
        education.setOnClickListener(this);
        gender.setOnClickListener(this);
        transportation.setOnClickListener(this);
        health.setOnClickListener(this);
        security.setOnClickListener(this);
        corruption.setOnClickListener(this);
        desertification.setOnClickListener(this);
        world.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.culture:
                Intent intt = new Intent(this,culture.class);
                startActivity(intt);
                break;
            case R.id.education:
                Intent innt = new Intent(this,education.class);
                startActivity(innt);
                break;
            case R.id.gender:
                Intent intnt = new Intent(this,gender.class);
                startActivity(intnt);
                break;
            case R.id.transportation:
                Intent intent = new Intent(this,transport.class);
                startActivity(intent);
                break;
            case R.id.health:
                Intent in = new Intent(this,health.class);
                startActivity(in);
                break;
            case R.id.security:
                Intent inn = new Intent(this,security.class);
                startActivity(inn);
                break;
            case R.id.corruption:
                Intent intn = new Intent(this,corruption.class);
                startActivity(intn);
                break;
            case R.id.world:
                Intent inte = new Intent(this,world.class);
                startActivity(inte);
                break;
            case R.id.desertification:
                Intent inten = new Intent(this,desertification.class);
                startActivity(inten);
                break;
        }
    }
}
